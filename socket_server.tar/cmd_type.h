enum eCmdType
{
	PL_RESET = 10
};